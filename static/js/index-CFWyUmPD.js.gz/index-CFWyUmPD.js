const __vite__mapDeps=(i,m=__vite__mapDeps,d=(m.f||(m.f=["static/js/index-BOqlvgaB.js","static/js/vue-router-CYC_ZM8h.js","static/js/@vue-CLcIJuOQ.js","static/js/store-D-KgEbVP.js","static/js/@ethereumjs-aMURc4PS.js","static/js/footer-BvkW0DW4.js","static/js/footer-_TZZ746-.js","static/js/web3-BEnxSq4_.js","static/js/setimmediate-DUOPLI_V.js","static/js/web3-eth-vWxzIr98.js","static/js/web3-types-DSrrWgZ8.js","static/js/web3-core-ObgmPHuP.js","static/js/web3-errors-hzVYhHGn.js","static/js/web3-eth-iban-75eRxAWM.js","static/js/web3-validator-BARD4gRE.js","static/js/ethereum-cryptography-wqlT3DIR.js","static/js/@noble-Cuw1cgUn.js","static/js/zod-D1IQRcUw.js","static/js/web3-utils-CA0vZo5F.js","static/js/eventemitter3-DvedpluM.js","static/js/web3-providers-http-C4pd9hst.js","static/js/cross-fetch-CvpS3L6O.js","static/js/web3-providers-ws-Fi9Qg3ru.js","static/js/isomorphic-ws-DZRFyHBe.js","static/js/web3-eth-accounts-DxnCIhbC.js","static/js/crc-32-BOb1C-oO.js","static/js/web3-rpc-methods-Df_8n9zL.js","static/js/web3-net-DSmyH1-b.js","static/js/web3-eth-abi-eT7or4Ei.js","static/js/abitype-BIaCt7HV.js","static/js/web3-eth-contract-CZNEMiMZ.js","static/js/web3-eth-ens-BC7enYQN.js","static/js/@adraffy-sBKPPea8.js","static/js/web3-eth-personal-CKSgBcUg.js","static/js/web3-rpc-providers-vULLkS0L.js","static/js/@ant-design-BL-uFhNg.js","static/js/@ctrl-CLxOqGL5.js","static/css/footer-Bk8BlpQJ.css","static/css/footer-bWsyEn12.css","static/js/mobile-line-CsnfXv5x.js","static/js/plus-icons-_imX99zj.js","static/js/pinia-CNFl7BY_.js","static/js/axios-Y7sjRXBH.js","static/css/index-DbkYO4yb.css","static/css/prismjs-54DrP_uy.css","static/js/index-B2hzJabX.js","static/css/index-BWWZL5qk.css","static/js/index-Cj0GfuLJ.js","static/css/index-_ZwETzBH.css","static/js/index-BIJtzUic.js","static/js/send-icon-CBqZMTDD.js","static/js/marked-6rvJW1hj.js","static/js/swiper-DWnYpmNd.js","static/css/swiper-BUrcyj0q.css","static/css/index-DVnByrmR.css","static/js/index-yEsN7GjR.js","static/css/index-COquAOlL.css"])))=>i.map(i=>d[i]);
import { p as e, w as t, B as a, C as o, D as n, E as s, F as r, G as l, H as i, I as c, z as d, J as u, T as p, K as m, L as v, r as g, M as h, N as f, O as y, P as w, Q as b, c as A, u as _, R as P, S as k, U as E } from "./@vue-CLcIJuOQ.js";

import { d as I, c as C } from "./pinia-CNFl7BY_.js";

import { s as S } from "./store-D-KgEbVP.js";

import { a as j } from "./axios-Y7sjRXBH.js";

import { W as U } from "./web3-BEnxSq4_.js";

import "./web3-core-ObgmPHuP.js";

import "./web3-types-DSrrWgZ8.js";

import "./web3-errors-hzVYhHGn.js";

import "./web3-eth-iban-75eRxAWM.js";

import "./web3-validator-BARD4gRE.js";

import "./setimmediate-DUOPLI_V.js";

import "./web3-eth-vWxzIr98.js";

import "./web3-eth-abi-eT7or4Ei.js";

import "./web3-eth-contract-CZNEMiMZ.js";

import "./web3-eth-personal-CKSgBcUg.js";

import "./web3-net-DSmyH1-b.js";

import "./web3-providers-http-C4pd9hst.js";

import "./isomorphic-ws-DZRFyHBe.js";

import "./web3-eth-accounts-DxnCIhbC.js";

import "./crc-32-BOb1C-oO.js";

import "./@ethereumjs-aMURc4PS.js";

import "./web3-eth-ens-BC7enYQN.js";

import "./web3-rpc-methods-Df_8n9zL.js";

import { u as T, c as L, a as H } from "./vue-router-CYC_ZM8h.js";

/* empty css                 */

import "./web3-utils-CA0vZo5F.js";

import "./ethereum-cryptography-wqlT3DIR.js";

import "./@noble-Cuw1cgUn.js";

import "./eventemitter3-DvedpluM.js";

import "./web3-rpc-providers-vULLkS0L.js";

import "./web3-providers-ws-Fi9Qg3ru.js";

import "./zod-D1IQRcUw.js";

import "./abitype-BIaCt7HV.js";

import "./cross-fetch-CvpS3L6O.js";

import "./@adraffy-sBKPPea8.js";

!function() {
    const e = document.createElement("link").relList;
    if (!(e && e.supports && e.supports("modulepreload"))) {
        for (const e of document.querySelectorAll('link[rel="modulepreload"]')) t(e);
        new MutationObserver((e => {
            for (const a of e) if ("childList" === a.type) for (const e of a.addedNodes) "LINK" === e.tagName && "modulepreload" === e.rel && t(e);
        })).observe(document, {
            childList: !0,
            subtree: !0
        });
    }
    function t(e) {
        if (e.ep) return;
        e.ep = !0;
        const t = function(e) {
            const t = {};
            return e.integrity && (t.integrity = e.integrity), e.referrerPolicy && (t.referrerPolicy = e.referrerPolicy), 
            "use-credentials" === e.crossOrigin ? t.credentials = "include" : "anonymous" === e.crossOrigin ? t.credentials = "omit" : t.credentials = "same-origin", 
            t;
        }(e);
        fetch(e.href, t);
    }
}();

function B(e) {
    return function(e) {
        for (var t = "0123456789abcdef", a = "", o = 0; o < 4 * e.length; o++) a += t.charAt(e[o >> 2] >> o % 4 * 8 + 4 & 15) + t.charAt(e[o >> 2] >> o % 4 * 8 & 15);
        return a;
    }(function(e, t) {
        e[t >> 5] |= 128 << t % 32, e[14 + (t + 64 >>> 9 << 4)] = t;
        for (var a = 1732584193, o = -271733879, n = -1732584194, s = 271733878, r = 0; r < e.length; r += 16) {
            var l = a, i = o, c = n, d = s;
            a = M(a, o, n, s, e[r + 0], 7, -680876936), s = M(s, a, o, n, e[r + 1], 12, -389564586), 
            n = M(n, s, a, o, e[r + 2], 17, 606105819), o = M(o, n, s, a, e[r + 3], 22, -1044525330), 
            a = M(a, o, n, s, e[r + 4], 7, -176418897), s = M(s, a, o, n, e[r + 5], 12, 1200080426), 
            n = M(n, s, a, o, e[r + 6], 17, -1473231341), o = M(o, n, s, a, e[r + 7], 22, -45705983), 
            a = M(a, o, n, s, e[r + 8], 7, 1770035416), s = M(s, a, o, n, e[r + 9], 12, -1958414417), 
            n = M(n, s, a, o, e[r + 10], 17, -42063), o = M(o, n, s, a, e[r + 11], 22, -1990404162), 
            a = M(a, o, n, s, e[r + 12], 7, 1804603682), s = M(s, a, o, n, e[r + 13], 12, -40341101), 
            n = M(n, s, a, o, e[r + 14], 17, -1502002290), a = O(a, o = M(o, n, s, a, e[r + 15], 22, 1236535329), n, s, e[r + 1], 5, -165796510), 
            s = O(s, a, o, n, e[r + 6], 9, -1069501632), n = O(n, s, a, o, e[r + 11], 14, 643717713), 
            o = O(o, n, s, a, e[r + 0], 20, -373897302), a = O(a, o, n, s, e[r + 5], 5, -701558691), 
            s = O(s, a, o, n, e[r + 10], 9, 38016083), n = O(n, s, a, o, e[r + 15], 14, -660478335), 
            o = O(o, n, s, a, e[r + 4], 20, -405537848), a = O(a, o, n, s, e[r + 9], 5, 568446438), 
            s = O(s, a, o, n, e[r + 14], 9, -1019803690), n = O(n, s, a, o, e[r + 3], 14, -187363961), 
            o = O(o, n, s, a, e[r + 8], 20, 1163531501), a = O(a, o, n, s, e[r + 13], 5, -1444681467), 
            s = O(s, a, o, n, e[r + 2], 9, -51403784), n = O(n, s, a, o, e[r + 7], 14, 1735328473), 
            a = z(a, o = O(o, n, s, a, e[r + 12], 20, -1926607734), n, s, e[r + 5], 4, -378558), 
            s = z(s, a, o, n, e[r + 8], 11, -2022574463), n = z(n, s, a, o, e[r + 11], 16, 1839030562), 
            o = z(o, n, s, a, e[r + 14], 23, -35309556), a = z(a, o, n, s, e[r + 1], 4, -1530992060), 
            s = z(s, a, o, n, e[r + 4], 11, 1272893353), n = z(n, s, a, o, e[r + 7], 16, -155497632), 
            o = z(o, n, s, a, e[r + 10], 23, -1094730640), a = z(a, o, n, s, e[r + 13], 4, 681279174), 
            s = z(s, a, o, n, e[r + 0], 11, -358537222), n = z(n, s, a, o, e[r + 3], 16, -722521979), 
            o = z(o, n, s, a, e[r + 6], 23, 76029189), a = z(a, o, n, s, e[r + 9], 4, -640364487), 
            s = z(s, a, o, n, e[r + 12], 11, -421815835), n = z(n, s, a, o, e[r + 15], 16, 530742520), 
            a = q(a, o = z(o, n, s, a, e[r + 2], 23, -995338651), n, s, e[r + 0], 6, -198630844), 
            s = q(s, a, o, n, e[r + 7], 10, 1126891415), n = q(n, s, a, o, e[r + 14], 15, -1416354905), 
            o = q(o, n, s, a, e[r + 5], 21, -57434055), a = q(a, o, n, s, e[r + 12], 6, 1700485571), 
            s = q(s, a, o, n, e[r + 3], 10, -1894986606), n = q(n, s, a, o, e[r + 10], 15, -1051523), 
            o = q(o, n, s, a, e[r + 1], 21, -2054922799), a = q(a, o, n, s, e[r + 8], 6, 1873313359), 
            s = q(s, a, o, n, e[r + 15], 10, -30611744), n = q(n, s, a, o, e[r + 6], 15, -1560198380), 
            o = q(o, n, s, a, e[r + 13], 21, 1309151649), a = q(a, o, n, s, e[r + 4], 6, -145523070), 
            s = q(s, a, o, n, e[r + 11], 10, -1120210379), n = q(n, s, a, o, e[r + 2], 15, 718787259), 
            o = q(o, n, s, a, e[r + 9], 21, -343485551), a = $(a, l), o = $(o, i), n = $(n, c), 
            s = $(s, d);
        }
        return Array(a, o, n, s);
    }(function(e) {
        for (var t = Array(), a = 255, o = 0; o < 8 * e.length; o += 8) t[o >> 5] |= (e.charCodeAt(o / 8) & a) << o % 32;
        return t;
    }(e), 8 * e.length));
}

function x(e, t, a, o, n, s) {
    return $((r = $($(t, e), $(o, s))) << (l = n) | r >>> 32 - l, a);
    var r, l;
}

function M(e, t, a, o, n, s, r) {
    return x(t & a | ~t & o, e, t, n, s, r);
}

function O(e, t, a, o, n, s, r) {
    return x(t & o | a & ~o, e, t, n, s, r);
}

function z(e, t, a, o, n, s, r) {
    return x(t ^ a ^ o, e, t, n, s, r);
}

function q(e, t, a, o, n, s, r) {
    return x(a ^ (t | ~o), e, t, n, s, r);
}

function $(e, t) {
    var a = (65535 & e) + (65535 & t);
    return (e >> 16) + (t >> 16) + (a >> 16) << 16 | 65535 & a;
}

function R(e) {
    const t = function(e) {
        let t = Object.keys(e).sort(), a = {};
        for (let o in t) a[t[o]] = encodeURIComponent(e[t[o]]);
        return a;
    }(e);
    let a = [];
    for (let o in t) o && t[o] && a.push(o.toLowerCase() + "=" + t[o]);
    return function(e) {
        return B(e);
    }(a.sort().join("&") + "&key=3GVxJe2dY0QWPnwYsgThHuplyltfAk5O");
}

const V = "ontouchstart" in window || navigator.maxTouchPoints > 0 || navigator.msMaxTouchPoints > 0, D = () => {
    document.body.style.overflow = "hidden", document.addEventListener("touchmove", (function() {}), !1);
}, N = () => {
    document.body.style.overflow = "", document.removeEventListener("touchmove", (function() {}), !1);
}, W = async e => {
    try {
        const t = await j({
            url: e,
            method: "GET",
            responseType: "blob"
        }), a = new Blob([ t.data ], {
            type: t.data.type
        }), o = document.createElement("a");
        o.href = window.URL.createObjectURL(a), o.download = e.split("/").reverse()[0], 
        document.body.appendChild(o), o.click(), document.body.removeChild(o);
    } catch (t) {}
}, G = {
    open(e) {
        ee().openModal(e);
    },
    close() {
        ee().closeModal();
    }
};

function F(e) {
    const t = document.createElement("textarea");
    t.value = e, document.body.appendChild(t), t.select();
    try {
        navigator.clipboard ? navigator.clipboard.writeText(e).then((() => {})).catch((t => {
            Y(e);
        })) : Y(e);
    } catch (a) {
        Y(e);
    } finally {
        document.body.removeChild(t);
    }
}

function Y(e) {
    const t = document.createElement("textarea");
    t.value = e, document.body.appendChild(t), t.select();
    try {
        document.execCommand("copy");
    } catch (a) {} finally {
        document.body.removeChild(t);
    }
}

const Q = {
    open: (e, t) => {
        ee().openMessage(e, t);
    }
}, K = j.create({
    // baseURL: "https://api.narralayer.ai/",//正式
    // baseURL: " https://883135a4d4d200c6.narralayer.ai",//测试
    baseURL: "https://api.narralayer.ai/",
    headers: {
        post: {
            "Content-Type": "application/json;charset=UTF-8",
            RspLanguage: "en"
        }
    }
});

K.interceptors.request.use((e => {
    const t = Z(), a = S.get("token", t.token);
    a && (e.headers.Authorization = `Bearer ${a}`), null == e.data && (e.data = {});
    const o =  (new Date).toUTCString();
    if ("get" === e.method) {
        const t = e.url + "?timestamp=" + o + "&signature=" + R({
            ...e.params
        });
        e.url = t;
    } else e.data.timestamp = o, e.data.signature = R({
        ...e.data
    });
    return "post" == e.method && (e.data = JSON.stringify(e.data)), e;
}), (e => Promise.reject(e))), K.interceptors.response.use((e => {
    var t, a;
    return Z(), 200 === (null == (t = e.data) ? void 0 : t.status) ? e : 401 !== (null == (a = e.data) ? void 0 : a.status) ? Promise.reject(e) : void G.open({
        title: "error",
        content: "Login timeout, please log in again."
    });
}), (e => {}));

const X = {
    getNews: async e => {
        try {
            return (await K.get("/api/App/Notice/SearchNotice", {
                params: e
            })).data.response;
        } catch (t) {}
    },
    submitEmail: async e => {
        try {
            return (await K.post("/api/App/Email/Submit", {
                EmailAddress: e
            })).data;
        } catch (t) {
            return Promise.reject(t.data.msg ?? "submit error");
        }
    },
    getuserManualAPI: async () => {
        try {
            return (await K.get("/api/App/Info/SearchUserManual")).data;
        } catch (e) {
            return Promise.reject(e.data.msg);
        }
    },
    submitAccessCodePassAPI: async e => {
        try {
            return (await K.post("/api/App/Email/SubmitAccessCodePass", e)).data;
        } catch (t) {
            return Promise.reject(t.data);
        }
    },
    loginAPI: async e => {
        try {
            return (await K.post("/api/App/Account/Login", e)).data;
        } catch (t) {
            return Promise.reject(t.data.msg);
        }
    },
    sendCodeAPI: async e => {
        try {
            return (await K.post("/api/App/Account/SendEmailCode", e)).data;
        } catch (t) {
            return Promise.reject(t.data.msg);
        }
    },
    forgetLoginPwdAPI: async e => {
        try {
            return (await K.post("/api/App/Account/ForgetLoginPwd", e)).data;
        } catch (t) {
            return Promise.reject(t.data.msg);
        }
    },
    registerAPI: async e => {
        try {
            return (await K.post("/api/App/Account/Register", e)).data;
        } catch (t) {
            return Promise.reject(t.data.msg);
        }
    },
    getUserInfoAPI: async () => {
        try {
            return (await K.get("/api/App/Account/RefreshMemberInfo")).data;
        } catch (e) {
            return Promise.reject(e.data.msg);
        }
    },
    editUserInfoAPI: async e => {
        try {
            return (await K.post("/api/App/Account/EditMemberInfo", e)).data;
        } catch (t) {
            return Promise.reject(t.data.msg);
        }
    },
    GetNonceAPI: async e => {
        try {
            return (await K.get("/api/App/Account/GetNonce", {
                params: e
            })).data;
        } catch (t) {
            return Promise.reject(t.data.msg);
        }
    },
    BindWalletAddressAPI: async e => {
        try {
            return (await K.post("/api/App/Account/BindWalletAddress", e)).data;
        } catch (t) {
            return Promise.reject(t.data.msg);
        }
    },
    GetQuizWebsiteAPI: async () => {
        try {
            return (await K.get("/api/App/Info/GetQuizWebsite")).data;
        } catch (e) {
            return Promise.reject(e.data.msg);
        }
    },
    googleLoginAPI: async e => {
        try {
            return (await K.post("/api/App/Account/GoogleLogin", e)).data;
        } catch (t) {
            return Promise.reject(t.data.msg);
        }
    },
    minrNftAPI: async e => {
        try {
            return (await K.post("/api/App/Nft/MintNft", e)).data;
        } catch (t) {
            return Promise.reject(t.data.msg);
        }
    },
    queryResultsAPI: async e => {
        try {
            return (await K.get("/api/App/Nft/QueryResult", {
                params: {
                    key: e
                }
            })).data;
        } catch (t) {
            return Promise.reject(t.data.msg);
        }
    }
}, J = {
    userInfo: {
        User_name: "",
        Bind_address: "",
        joinDate: "",
        Email: "",
        Access_code: "",
        Is_newsletter: !1
    },
    token: S.get("token", ""),
    sendSecond: 0,
    quiz: ""
}, Z = I("user", {
    state: () => ({
        ...J
    }),
    actions: {
        setUserInfo(e) {
            this.userInfo = e, S.set("userInfo", this.userInfo);
        },
        resetHandle() {
            S.remove("userInfo"), S.remove("token"), this.userInfo = {}, this.token = "";
        },
        setToken(e) {
            this.token = e, S.set("token", this.token);
        },
        async loginHandle(e) {
            const t = await X.loginAPI(e);
            this.setToken(t.response.Token), this.getUserInfo();
        },
        async googleLoginHandle(e) {
            const t = await X.googleLoginAPI(e);
            this.setToken(t.response.Token), this.getUserInfo();
        },
        async getUserInfo() {
            const e = await X.getUserInfoAPI();
            this.setUserInfo({
                ...e.response,
                joinDate: function(e) {
                    const t = new Date(e);
                    return `${t.getFullYear().toString().replace("20", "")}/${String(t.getMonth() + 1).padStart(2, "0")}/${String(t.getDate()).padStart(2, "0")}`;
                }(e.response.Regist_time)
            });
            const t = await X.GetQuizWebsiteAPI();
            this.quiz = t.response;
        },
        logoutHandle() {
            this.resetHandle();
        },
        //查询账户
        async getWalletAccount() {
            const e = ee();
            if (S.get("token", this.token)) if (window.ethereum) {
                try {
                    await window.ethereum.request({
                        method: "wallet_switchEthereumChain",
                        params: [ {
                            chainId: "0x138d4"
                        } ]
                    });
                } catch (t) {
                    try {
                        await window.ethereum.request({
                            method: "wallet_addEthereumChain",
                            params: [ {
                                chainId: "0x138d4",
                                // 目标链ID
                                chainName: "Berachain bArtio",
                                nativeCurrency: {
                                    name: "BERA",
                                    symbol: "BERA",
                                    decimals: 18
                                },
                                rpcUrls: [ "https://bartio.rpc.berachain.com" ],
                                // 节点
                                blockExplorerUrls: [ "https://bartio.beratrail.io" ]
                            } ]
                        });
                    } catch (a) {
                        return void e.openModal({
                            title: "error",
                            type: "error",
                            content: "Adding chain failed !"
                        });
                    }
                    return;
                }
                try {
                    const t = await window.ethereum.request({
                        method: "eth_requestAccounts"
                    });
                    return t ? t[0] : void e.openModal({
                        title: "error",
                        type: "error",
                        content: "Get account failed !"
                    });
                } catch (o) {
                    return void e.openModal({
                        title: "error",
                        type: "error",
                        content: "Get account failed !"
                    });
                }
            } else e.openModal({
                title: "error",
                type: "error",
                content: "Please install the wallet !"
            }); else e.openModal({
                title: "error",
                type: "error",
                content: "please login first!"
            });
        },
        //获取密钥
        async getWalletCode(e) {
            const t = ee();
            try {
                const t = new U(window.ethereum), a = await X.GetNonceAPI({
                    address: e
                }), o = await t.eth.personal.sign(a.response, e, "dsa");
                if (o) {
                    return {
                        auth_code: this.quiz.split("/").reverse()[0],
                        signmsg: o,
                        address: e,
                        Name: "name",
                        Char_main: "char_main",
                        Char_alt: "char_alt",
                        Percent_main: 1,
                        Percent_alt: 1
                    };
                }
            } catch (a) {
                return void t.openModal({
                    title: "error",
                    type: "error",
                    content: a
                });
            }
        },
        //铸造
        async minrNftHandle() {
            const e = ee();
            e.openModal({
                content: "loading..."
            });
            const t = await this.getWalletAccount();
            if (!t) return;
            const a = await this.getWalletCode(t);
            if (a) try {
                const t = await X.minrNftAPI(a);
                let o = !1, n = null;
                n = setInterval((() => {
                    o ? clearInterval(n) : X.queryResultsAPI(t.response).then((t => {
                        2 === t.response.Status ? (o = !0, e.openModal({
                            title: "success",
                            type: "success",
                            content: "Mint successful!"
                        }), this.getUserInfo()) : 3 === t.response.Status && (o = !0, e.openModal({
                            title: "error",
                            type: "error",
                            content: t.response.Err_msg
                        }));
                    })).catch((t => {
                        o = !0, e.openModal({
                            title: "success",
                            type: "success",
                            content: t
                        });
                    }));
                }), 1e3);
            } catch (o) {
                this.isMinting = !0, e.openModal({
                    title: "error",
                    type: "error",
                    content: o
                });
            }
        }
    }
}), ee = I("app", {
    state: () => ({
        media: S.get("media", "pc"),
        // 'light|dark'
        mediaSizeList: [ {
            name: "pc",
            size: 3.93
        }, {
            name: "pad",
            size: 10.24
        }, {
            name: "mobile",
            size: 3.93
        } ],
        mediaSize: S.get("mediaSize", 14.4),
        musicToggle: !1,
        scrollY: 0,
        modalOpen: !1,
        modalTitle: "",
        modalContent: "",
        modalType: "default",
        //'default'|'type'
        debugStr: "",
        quizOpen: !1,
        isLoaded: !1,
        messageOpen: !1,
        messageContent: "",
        messageDuration: 1500
    }),
    actions: {
        setMedia(e) {
            S.set("media", e), this.media = e, this.mediaSize = this.mediaSizeList.find((e => e.name === this.media)).size, 
            S.set("mediaSize", this.mediaSize);
        },
        setMusicToggle(e) {
            this.musicToggle = "boolean" != typeof e ? !this.musicToggle : e;
        },
        openModal(e) {
            this.modalOpen = !0, this.modalTitle = e.title, this.modalContent = e.content, this.modalType = e.type || "";
        },
        closeModal(e) {
            this.modalOpen = !1, this.modalTitle = "", this.modalContent = "", this.modalType = "";
        },
        debug(e) {
            this.debugStr += "<br>" + e;
        },
        toQuiz() {
            const e = Z();
            S.get("token", e.token) ? window.open(e.quiz, "_blank") : this.quizOpen = !0;
        },
        openMessage(e, t) {
            this.messageOpen = !0, this.messageContent = e, setTimeout((() => {
                this.messageOpen = !1;
            }), t || this.messageDuration);
        }
    }
}), te = (e, t) => {
    const a = e.__vccOpts || e;
    for (const [o, n] of t) a[o] = n;
    return a;
}, ae = {
    class: "modal-main"
}, oe = {
    class: "inner"
}, ne = {
    class: "content"
}, se =  te({
    __name: "Modal-A",
    props: {
        title: String,
        content: String,
        open: {
            type: Boolean,
            default: !1
        },
        type: {
            type: String,
            default: ""
        }
    },
    emits: [ "update:open" ],
    setup(g, {emit: h}) {
        const f = ee(), y = h, w = g, b = e({
            get: () => w.open,
            set(e) {
                y("update:open", e);
            }
        }), A = e => {};
        return t(b, (e => {
            e ? D() : N();
        })), a((() => {
            N();
        })), (e, t) => (o(), n(p, null, {
            default: s((() => [ b.value ? (o(), r("div", {
                key: 0,
                class: i([ "modal", d(f).media + "-modal" ]),
                onClick: A
            }, [ l("div", ae, [ l("img", {
                onClick: t[0] || (t[0] = e => b.value = !1),
                class: "icon",
                src: "data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAABgAAAAYCAYAAADgdz34AAAACXBIWXMAAAsTAAALEwEAmpwYAAAAAXNSR0IArs4c6QAAAARnQU1BAACxjwv8YQUAAACbSURBVHgB7ZRrCoAgEISXTuAROkI3qiPXSeoGk6KBhOn4KPrhwELhOJ+PRZGuXwqA0jW+4jdGWO26JsI/OS8Y/zUBDOQWjpxdLClIIHyWHMUg1eExSLPwCKRd+AMkK3wQTquuw/s335u0UODMgxffKnwG0cLF4d5YHQREKxZDYN8iqhUDEMUAlAdItqIHMXNGYeR2kV5Nob/rW53xqs7n/Mx8awAAAABJRU5ErkJggg==",
                alt: ""
            }), l("div", oe, [ l("h1", {
                class: i([ "title", w.title ])
            }, [ c(e.$slots, "title", {}, (() => [ m(v(w.title), 1) ]), !0) ], 2), l("div", ne, [ c(e.$slots, "default", {}, (() => [ m(v(w.content), 1) ]), !0) ]) ]) ]) ], 2)) : u("", !0) ])),
            _: 3
        }));
    }
}, [ [ "__scopeId", "data-v-70a3a999" ] ]), re = "/narra-homepage/static/png/login-error-lkDCjkpS.png", le =  te({
    __name: "LoginError",
    setup(e, {expose: t}) {
        const a = g(!1);
        return t({
            openHandle: () => {
                a.value = !0;
            }
        }), (e, t) => (o(), n(se, {
            open: a.value,
            "onUpdate:open": t[0] || (t[0] = e => a.value = e)
        }, {
            title: s((() => t[1] || (t[1] = [ l("span", {
                style: {
                    color: "#F52B11"
                }
            }, " Incorrect Email Address/Password ", -1) ]))),
            default: s((() => [ t[2] || (t[2] = l("div", {
                class: "content"
            }, "The email address and/or password is incorrect. Please try again.", -1)), t[3] || (t[3] = l("img", {
                class: "error-bg",
                src: re,
                alt: ""
            }, null, -1)) ])),
            _: 1
        }, 8, [ "open" ]));
    }
}, [ [ "__scopeId", "data-v-dcd4a2e7" ] ]), ie = "/narra-homepage/static/svg/eyes-Du94lnAM.svg", ce = {
    class: "label"
}, de = {
    class: "wrapper"
}, ue = [ "disabled", "onUpdate:modelValue", "onBlur" ], pe = {
    class: "errormsg"
}, me =  te({
    __name: "myForm",
    props: {
        formList: Object
    },
    emits: [ "update:formList" ],
    setup(t, {expose: a, emit: n}) {
        const s = ee(), u = t, p = n, m = e({
            get: () => u.formList,
            set(e) {
                p("update:formList", e);
            }
        }), g = e => {
            e.validate && e.validate(e.value, (t => {
                m.value.forEach((a => {
                    a.key === e.key && (a.errormsg = t);
                }));
            }));
        };
        return a({
            validate: () => new Promise(((e, t) => {
                if (m.value.forEach((e => g(e))), m.value.every((e => !e.errormsg))) {
                    const t = {};
                    m.value.forEach((e => {
                        t[e.key] = e.value;
                    })), e(t);
                } else t();
            }))
        }), (e, t) => (o(), r("div", {
            class: i([ "form-container", d(s).media + "-form" ])
        }, [ (o(!0), r(h, null, f(m.value, (t => (o(), r("div", {
            class: "form-item",
            key: t.key
        }, [ l("h3", ce, v(t.label), 1), l("div", de, [ c(e.$slots, t.key, {
            i: t
        }, (() => [ y(l("input", b({
            disabled: t.disabled,
            "onUpdate:modelValue": e => t.value = e,
            class: [ "input", t.errormsg && "error" ],
            ref_for: !0
        }, t.props, {
            onBlur: e => g(t)
        }), null, 16, ue), [ [ w, t.value ] ]), l("div", pe, v(t.errormsg), 1) ]), !0) ]) ])))), 128)) ], 2));
    }
}, [ [ "__scopeId", "data-v-bd36505b" ] ]), ve = /^(?=.*[A-Za-z])(?=.*\d)[A-Za-z\d]{8,16}$/, ge = /^[^\s@]+@[^\s@]+\.[^\s@]+$/, he = /^[a-zA-Z0-9]{4,30}$/, fe = {
    class: "content"
}, ye = [ "type", "onUpdate:modelValue", "onBlur" ], we = [ "onClick" ], be = {
    class: "errormsg"
}, Ae = [ "type", "onUpdate:modelValue", "onBlur" ], _e = [ "onClick" ], Pe = {
    class: "errormsg"
}, ke = [ "disabled" ], Ee =  te({
    __name: "CreateAccount",
    emits: [ "error", "success" ],
    setup(t, {expose: a, emit: r}) {
        const c = r, d = g([]), u = g(), p = e => {
            e.showPassword = !0, setTimeout((() => {
                e.showPassword = !1;
            }), 3e3);
        }, m = g(!1), h = e((() => d.value.every((e => !!e.Optional || e.value)))), f = g(!1), _ = T(), P = e => {
            e.validate && e.validate(e.value, (t => {
                d.value.forEach((a => {
                    a.key === e.key && (a.errormsg = t);
                }));
            }));
        }, k = () => {
            u.value.validate().then((e => {
                const t = {
                    ...e
                };
                f.value = !0, X.sendCodeAPI({
                    Email: e.account
                }).then((e => {
                    c("success", t);
                })).catch((e => {
                    G.open({
                        title: "error",
                        content: e,
                        type: "error"
                    });
                })).finally((() => {
                    f.value = !1;
                }));
            }));
        };
        return a({
            openHandle: () => {
                var e;
                m.value = !0, d.value = [ {
                    label: "Username",
                    value: "",
                    key: "User_name",
                    validate: (e, t) => {
                        e ? he.test(e) ? t() : t("The username length must be 8-16 characters, including letters and numbers.") : t("Please enter your username");
                    },
                    props: {
                        placeholder: "Enter your username"
                    }
                }, {
                    label: "Email Address",
                    value: "",
                    key: "account",
                    validate: (e, t) => {
                        e ? ge.test(e) ? t() : t("The email address is incorrect") : t("Please enter your email address");
                    },
                    props: {
                        placeholder: "Enter your email address"
                    }
                }, {
                    label: "Password",
                    value: "",
                    key: "pwd",
                    showPassword: !1,
                    validate: (e, t) => {
                        e ? ve.test(e) ? t() : t("The password length must be 8-16 characters, including letters and numbers.") : t("Please enter your password");
                    },
                    props: {
                        placeholder: "Enter your password"
                    }
                }, {
                    label: "Confirm Password",
                    value: "",
                    key: "confirmPwd",
                    showPassword: !1,
                    validate: (e, t) => {
                        e ? e !== d.value.find((e => "pwd" === e.key)).value ? t("Password does not match") : t() : t("Please enter your confirm password");
                    },
                    props: {
                        placeholder: "Enter your confirm password"
                    }
                }, {
                    label: "Access Code(Optional)",
                    value: (null == (e = null == _ ? void 0 : _.query) ? void 0 : e.ic) || "",
                    key: "Access_code",
                    Optional: !0,
                    validate: (e, t) => {
                        t();
                    },
                    props: {
                        placeholder: "Enter your access code"
                    }
                } ];
            },
            closeHandle: () => {
                m.value = !1;
            }
        }), (e, t) => (o(), n(se, {
            title: "Create Account",
            open: m.value,
            "onUpdate:open": t[1] || (t[1] = e => m.value = e)
        }, {
            default: s((() => [ l("div", fe, [ A(me, {
                ref_key: "myForm",
                ref: u,
                "form-list": d.value,
                "onUpdate:formList": t[0] || (t[0] = e => d.value = e)
            }, {
                pwd: s((({i: e}) => [ y(l("input", b({
                    type: e.showPassword ? "text" : "password",
                    "onUpdate:modelValue": t => e.value = t,
                    class: [ "input", e.errormsg && "error" ]
                }, e.props, {
                    onBlur: t => P(e)
                }), null, 16, ye), [ [ w, e.value ] ]), l("img", {
                    class: i([ "icon", {
                        eyesDisabled: e.showPassword
                    } ]),
                    onClick: t => p(e),
                    src: ie,
                    alt: ""
                }, null, 10, we), l("div", be, v(e.errormsg), 1) ])),
                confirmPwd: s((({i: e}) => [ y(l("input", b({
                    type: e.showPassword ? "text" : "password",
                    "onUpdate:modelValue": t => e.value = t,
                    class: [ "input", e.errormsg && "error" ]
                }, e.props, {
                    onBlur: t => P(e)
                }), null, 16, Ae), [ [ w, e.value ] ]), l("img", {
                    class: i([ "icon", {
                        eyesDisabled: e.showPassword
                    } ]),
                    onClick: t => p(e),
                    src: ie,
                    alt: ""
                }, null, 10, _e), l("div", Pe, v(e.errormsg), 1) ])),
                _: 1
            }, 8, [ "form-list" ]), l("button", {
                onClick: k,
                disabled: !h.value || f.value,
                class: "submit"
            }, v(f.value ? "loading..." : "Sign up"), 9, ke) ]) ])),
            _: 1
        }, 8, [ "open" ]));
    }
}, [ [ "__scopeId", "data-v-60f788ed" ] ]), Ie = {
    class: "content"
}, Ce = [ "type", "onUpdate:modelValue", "onBlur" ], Se = {
    class: "errormsg"
}, je = [ "disabled" ], Ue =  te({
    __name: "Login",
    emits: [ "error", "forget", "create" ],
    setup(t, {expose: a, emit: r}) {
        const c = r, d = g([]), u = g(!1), p = Z(), h = () => {
            u.value = !0, setTimeout((() => {
                u.value = !1;
            }), 3e3);
        }, f = g(!1), _ = e((() => d.value.every((e => e.value)))), P = g(), k = g(!1), E = () => {
            P.value.validate().then((e => {
                k.value = !0, p.loginHandle(e).then((e => {
                    c("success"), f.value = !1;
                })).catch((() => {
                    c("error");
                })).finally((() => {
                    k.value = !1;
                }));
            }));
        }, I = () => {
            c("forget"), f.value = !1;
        }, C = () => {
            c("create"), f.value = !1;
        };
        return a({
            openHandle: e => {
                f.value = !0, d.value = [ {
                    label: "Email Address",
                    value: e ? e.account : "",
                    key: "account",
                    validate: (e, t) => {
                        e ? ge.test(e) ? t() : t("The email address is incorrect") : t("Please enter your email address");
                    },
                    props: {
                        placeholder: "Enter your email address"
                    }
                }, {
                    label: "Password",
                    value: e ? e.pwd : "",
                    key: "pwd",
                    validate: (e, t) => {
                        e ? ve.test(e) ? t() : t("The password length must be 8-16 characters, including letters and numbers.") : t("Please enter your Password");
                    },
                    props: {
                        placeholder: "Enter your password"
                    }
                } ];
            },
            closeHandle: () => {
                f.value = !1;
            }
        }), (e, t) => (o(), n(se, {
            title: "Login",
            open: f.value,
            "onUpdate:open": t[1] || (t[1] = e => f.value = e)
        }, {
            default: s((() => [ l("div", Ie, [ A(me, {
                ref_key: "form",
                ref: P,
                "form-list": d.value,
                "onUpdate:formList": t[0] || (t[0] = e => d.value = e)
            }, {
                pwd: s((({i: e}) => [ y(l("input", b({
                    type: u.value ? "text" : "password",
                    "onUpdate:modelValue": t => e.value = t,
                    class: [ "input", e.errormsg && "error" ]
                }, e.props, {
                    onBlur: t => {
                        var a;
                        (a = e).validate && a.validate(a.value, (e => {
                            d.value.forEach((t => {
                                t.key === a.key && (t.errormsg = e);
                            }));
                        }));
                    }
                }), null, 16, Ce), [ [ w, e.value ] ]), l("img", {
                    class: i([ "icon", {
                        eyesDisabled: u.value
                    } ]),
                    onClick: h,
                    src: ie,
                    alt: ""
                }, null, 2), l("div", Se, v(e.errormsg), 1) ])),
                _: 1
            }, 8, [ "form-list" ]), l("button", {
                onClick: E,
                disabled: !_.value || k.value,
                class: "login"
            }, v(k.value ? "LoggingIn..." : "Login"), 9, je), l("a", {
                onClick: I,
                class: "forget"
            }, "Forget password ?"), l("span", {
                class: "create"
            }, [ t[2] || (t[2] = m(" Don’t have an account? Create one ")), l("a", {
                onClick: C
            }, " here"), t[3] || (t[3] = m(". ")) ]) ]) ])),
            _: 1
        }, 8, [ "open" ]));
    }
}, [ [ "__scopeId", "data-v-1dc4da2e" ] ]), Te = "/narra-homepage/static/png/create-success-AMi6BPdb.png", Le =  te({
    __name: "CreateSuccess",
    emits: [ "login" ],
    setup(e, {expose: t, emit: a}) {
        const r = g(!1), i = a;
        return t({
            openHandle: e => {
                r.value = !0, setTimeout((() => {
                    r.value = !1, i("login", e);
                }), 2e3);
            }
        }), (e, t) => (o(), n(se, {
            open: r.value,
            "onUpdate:open": t[0] || (t[0] = e => r.value = e)
        }, {
            title: s((() => t[1] || (t[1] = [ l("span", {
                style: {
                    color: "#12B424"
                }
            }, " Congratulations ", -1) ]))),
            default: s((() => [ t[2] || (t[2] = l("div", {
                class: "content"
            }, [ m("Welcome to Narra! We’re looking forward to chatting with you!"), l("br"), l("span", {
                class: "loading"
            }) ], -1)), t[3] || (t[3] = l("img", {
                class: "error-bg",
                src: Te,
                alt: ""
            }, null, -1)) ])),
            _: 1
        }, 8, [ "open" ]));
    }
}, [ [ "__scopeId", "data-v-f1a8331b" ] ]), He = {
    class: "content"
}, Be = [ "disabled" ], xe =  te({
    __name: "SendEmail",
    props: {
        des: {
            type: String,
            default: "Don’t worry we got you! Please enter the email to recover your account."
        }
    },
    emits: [ "success", "error" ],
    setup(t, {expose: a, emit: r}) {
        const i = t, c = g([]), d = g(!1), u = g(!1), p = r, m = e((() => c.value.every((e => e.value)))), h = g(), f = () => {
            h.value.validate().then((e => {
                d.value = !0, X.sendCodeAPI(e).then((() => {
                    p("success", e.Email), u.value = !1;
                })).catch((e => {
                    p("error"), G.open({
                        title: "error",
                        content: e,
                        type: "error"
                    });
                })).finally((() => {
                    d.value = !1;
                }));
            }));
        };
        return a({
            openHandle: () => {
                u.value = !0, c.value = [ {
                    label: "Email Address",
                    value: "",
                    key: "Email",
                    validate: (e, t) => {
                        e || t("Please enter your email address"), ge.test(e) ? t() : t("The email address is incorrect");
                    },
                    props: {
                        placeholder: "exampleemail@gmail.com"
                    }
                } ];
            },
            closeHandle: () => {
                u.value = !1;
            }
        }), (e, t) => (o(), n(se, {
            title: "Forget Password",
            open: u.value,
            "onUpdate:open": t[1] || (t[1] = e => u.value = e)
        }, {
            default: s((() => [ l("div", He, [ l("p", null, v(i.des), 1), A(me, {
                ref_key: "form",
                ref: h,
                "form-list": c.value,
                "onUpdate:formList": t[0] || (t[0] = e => c.value = e)
            }, null, 8, [ "form-list" ]), l("button", {
                onClick: f,
                disabled: !m.value || d.value,
                class: "submit"
            }, v(d.value ? "Sending..." : "Send"), 9, Be) ]) ])),
            _: 1
        }, 8, [ "open" ]));
    }
}, [ [ "__scopeId", "data-v-87525191" ] ]), Me = [ "disabled" ], Oe = {
    key: 0,
    class: "seconds"
}, ze =  te({
    __name: "ResendCode",
    props: {
        address: String
    },
    setup(e) {
        const t = ee(), a = Z(), n = e, s = g(null), l = () => {
            a.sendSecond = 60, s.value = null, s.value = setInterval((() => {
                a.sendSecond--, 0 === a.sendSecond && clearInterval(s.value);
            }), 1e3);
        }, c = () => {
            X.sendCodeAPI({
                address: n.address
            }).then((e => {
                l();
            }));
        };
        return _((() => {
            l();
        })), (e, n) => (o(), r("button", {
            onClick: c,
            disabled: 0 !== d(a).sendSecond,
            class: i([ "resend", d(t).media + "-resend" ])
        }, [ 0 !== d(a).sendSecond ? (o(), r("span", Oe, v(d(a).sendSecond + "s"), 1)) : u("", !0), n[0] || (n[0] = m(" resend ")) ], 10, Me));
    }
}, [ [ "__scopeId", "data-v-651e6785" ] ]), qe = {
    class: "content"
}, $e = [ "onUpdate:modelValue", "onBlur" ], Re = {
    class: "errormsg"
}, Ve = [ "type", "onUpdate:modelValue", "onBlur" ], De = [ "onClick" ], Ne = {
    class: "errormsg"
}, We = [ "type", "onUpdate:modelValue", "onBlur" ], Ge = [ "onClick" ], Fe = {
    class: "errormsg"
}, Ye = [ "disabled" ], Qe =  te({
    __name: "CodeVerification",
    emits: [ "send", "error" ],
    setup(t, {expose: a, emit: r}) {
        const c = g([]), d = g(!1), u = r, p = e((() => c.value.every((e => e.value)))), m = g(!1);
        Z();
        const h = g(), f = g(""), _ = e => {
            e.showPassword = !0, setTimeout((() => {
                e.showPassword = !1;
            }), 3e3);
        }, P = e => {
            e.validate && e.validate(e.value, (t => {
                c.value.forEach((a => {
                    a.key === e.key && (a.errormsg = t);
                }));
            }));
        }, k = () => {
            h.value.validate().then((e => {
                const t = {
                    account: f.value,
                    ...e
                };
                m.value = !0, X.forgetLoginPwdAPI(t).then((e => {
                    u("success"), d.value = !1;
                })).catch((e => {
                    G.open({
                        title: "error",
                        content: e,
                        type: "error"
                    });
                })).finally((() => {
                    m.value = !1;
                }));
            }));
        };
        return a({
            openHandle: e => {
                f.value = e, d.value = !0, c.value = [ {
                    label: "Verification Code",
                    value: "",
                    key: "code",
                    validate: (e, t) => {
                        e || t("Please enter your verification code"), e.length < 6 ? t("The verification code is incorrect") : t();
                    },
                    props: {
                        placeholder: "Please enter your verification code"
                    }
                }, {
                    label: "New Password",
                    value: "",
                    key: "pwd",
                    validate: (e, t) => {
                        e || t("Please enter your new password"), ve.test(e) ? t() : t("The password length must be 8-16 characters, including letters and numbers.");
                    },
                    props: {
                        placeholder: "Please enter your new password"
                    }
                }, {
                    label: "Confirm New Password",
                    value: "",
                    key: "confirmPwd",
                    validate: (e, t) => {
                        e || t("Please enter your confirm new password"), e !== c.value.find((e => "pwd" === e.key)).value ? t("The password entered needs to be consistent") : t();
                    },
                    props: {
                        placeholder: "Please enter your confirm new password"
                    }
                } ];
            },
            closeHandle: () => {
                d.value = !1;
            }
        }), (e, t) => (o(), n(se, {
            title: "Request Granted",
            open: d.value,
            "onUpdate:open": t[1] || (t[1] = e => d.value = e)
        }, {
            default: s((() => [ l("div", qe, [ t[2] || (t[2] = l("p", {
                style: {
                    width: "100%"
                }
            }, "We’re on it! An email will be sent to you shortly", -1)), A(me, {
                ref_key: "form",
                ref: h,
                "form-list": c.value,
                "onUpdate:formList": t[0] || (t[0] = e => c.value = e)
            }, {
                code: s((({i: e}) => [ y(l("input", b({
                    "onUpdate:modelValue": t => e.value = t,
                    class: [ "input codeInput", e.errormsg && "error" ]
                }, e.props, {
                    onBlur: t => P(e)
                }), null, 16, $e), [ [ w, e.value ] ]), A(ze, {
                    class: "resend",
                    address: f.value
                }, null, 8, [ "address" ]), l("div", Re, v(e.errormsg), 1) ])),
                pwd: s((({i: e}) => [ y(l("input", b({
                    type: e.showPassword ? "text" : "password",
                    "onUpdate:modelValue": t => e.value = t,
                    class: [ "input", e.errormsg && "error" ]
                }, e.props, {
                    onBlur: t => P(e)
                }), null, 16, Ve), [ [ w, e.value ] ]), l("img", {
                    class: i([ "icon", {
                        eyesDisabled: e.showPassword
                    } ]),
                    onClick: t => _(e),
                    src: ie,
                    alt: ""
                }, null, 10, De), l("div", Ne, v(e.errormsg), 1) ])),
                confirmPwd: s((({i: e}) => [ y(l("input", b({
                    type: e.showPassword ? "text" : "password",
                    "onUpdate:modelValue": t => e.value = t,
                    class: [ "input", e.errormsg && "error" ]
                }, e.props, {
                    onBlur: t => P(e)
                }), null, 16, We), [ [ w, e.value ] ]), l("img", {
                    class: i([ "icon", {
                        eyesDisabled: e.showPassword
                    } ]),
                    onClick: t => _(e),
                    src: ie,
                    alt: ""
                }, null, 10, Ge), l("div", Fe, v(e.errormsg), 1) ])),
                _: 1
            }, 8, [ "form-list" ]), l("button", {
                onClick: k,
                disabled: !p.value || m.value,
                class: "submit"
            }, v(m.value ? "Sending..." : "Send"), 9, Ye) ]) ])),
            _: 1
        }, 8, [ "open" ]));
    }
}, [ [ "__scopeId", "data-v-76a05b2e" ] ]), Ke =  te({
    __name: "ForgetError",
    emits: [ "create" ],
    setup(e, {expose: t, emit: a}) {
        const r = g(!1), i = a, c = () => {
            r.value = !1, i("create");
        };
        return t({
            openHandle: () => {
                r.value = !0;
            }
        }), (e, t) => (o(), n(se, {
            open: r.value,
            "onUpdate:open": t[0] || (t[0] = e => r.value = e)
        }, {
            title: s((() => t[1] || (t[1] = [ l("span", {
                style: {
                    color: "#F52B11"
                }
            }, " Invalid Email ", -1) ]))),
            default: s((() => [ l("div", {
                class: "content"
            }, [ t[2] || (t[2] = m("We can’t find this email in our records. Please try again. ")), t[3] || (t[3] = l("br", null, null, -1)), t[4] || (t[4] = l("br", null, null, -1)), t[5] || (t[5] = m("Don’t have an account?")), t[6] || (t[6] = l("br", null, null, -1)), t[7] || (t[7] = m(" You can sign up ")), l("a", {
                onClick: c
            }, "here"), t[8] || (t[8] = m(".")) ]), t[9] || (t[9] = l("img", {
                class: "error-bg",
                src: re,
                alt: ""
            }, null, -1)) ])),
            _: 1
        }, 8, [ "open" ]));
    }
}, [ [ "__scopeId", "data-v-d9829b9e" ] ]), Xe = {
    class: "content"
}, Je = [ "disabled" ], Ze =  te({
    __name: "CreateTakeCode",
    emits: [ "send", "error" ],
    setup(t, {expose: a, emit: r}) {
        const i = g([]), c = g(!1), d = r, u = e((() => i.value.every((e => e.value)))), p = g(!1);
        Z();
        const m = g(), h = g({}), f = () => {
            m.value.validate().then((e => {
                p.value = !0;
                const t = {
                    account: h.value.account,
                    pwd: h.value.pwd,
                    User_name: h.value.User_name,
                    Access_code: h.value.Access_code,
                    code: e.code
                };
                X.registerAPI(t).then((e => {
                    d("success", t), c.value = !1;
                })).catch((e => {
                    G.open({
                        title: "error",
                        content: e,
                        type: "error"
                    });
                })).finally((() => {
                    p.value = !1;
                }));
            }));
        };
        return a({
            openHandle: e => {
                h.value = e, c.value = !0, i.value = [ {
                    label: "Verification Code",
                    value: "",
                    key: "code",
                    validate: (e, t) => {
                        e || t("Please enter your verification code"), e.length < 6 ? t("The verification code is incorrect") : t();
                    },
                    props: {
                        placeholder: "Please enter your verification code"
                    }
                } ];
            },
            closeHandle: () => {
                c.value = !1;
            }
        }), (e, t) => (o(), n(se, {
            title: "Request Granted",
            open: c.value,
            "onUpdate:open": t[1] || (t[1] = e => c.value = e)
        }, {
            default: s((() => [ l("div", Xe, [ t[2] || (t[2] = l("p", {
                style: {
                    width: "100%"
                }
            }, "We are currently in progress! We will send you an email soon, please verify. ", -1)), A(me, {
                ref_key: "form",
                ref: m,
                "form-list": i.value,
                "onUpdate:formList": t[0] || (t[0] = e => i.value = e)
            }, null, 8, [ "form-list" ]), l("button", {
                onClick: f,
                disabled: !u.value || p.value,
                class: "submit"
            }, v(p.value ? "Sending..." : "Send"), 9, Je) ]) ])),
            _: 1
        }, 8, [ "open" ]));
    }
}, [ [ "__scopeId", "data-v-3558148b" ] ]), et =  te({
    __name: "VerificationFailed",
    setup(e, {expose: t}) {
        const a = g(!1);
        return t({
            openHandle: () => {
                a.value = !0;
            }
        }), (e, t) => (o(), n(se, {
            open: a.value,
            "onUpdate:open": t[0] || (t[0] = e => a.value = e)
        }, {
            title: s((() => t[1] || (t[1] = [ l("span", {
                style: {
                    color: "#F52B11"
                }
            }, " Error ", -1) ]))),
            default: s((() => [ t[2] || (t[2] = l("div", {
                class: "content"
            }, "Verification failed, please try again.", -1)), t[3] || (t[3] = l("img", {
                class: "error-bg",
                src: re,
                alt: ""
            }, null, -1)) ])),
            _: 1
        }, 8, [ "open" ]));
    }
}, [ [ "__scopeId", "data-v-048e992e" ] ]), tt =  te({
    __name: "ForgetSuccess",
    emits: [ "close" ],
    setup(e, {expose: a, emit: r}) {
        const i = g(!1), c = r;
        return t(i, (() => {
            i.value || c("close");
        })), a({
            openHandle: e => {
                i.value = !0, setTimeout((() => {
                    i.value = !1;
                }), 2e3);
            }
        }), (e, t) => (o(), n(se, {
            open: i.value,
            "onUpdate:open": t[0] || (t[0] = e => i.value = e)
        }, {
            title: s((() => t[1] || (t[1] = [ l("span", {
                style: {
                    color: "#12B424"
                }
            }, " Request Granted ", -1) ]))),
            default: s((() => [ t[2] || (t[2] = l("div", {
                class: "content"
            }, "Modified successfully, please log in !", -1)), t[3] || (t[3] = l("img", {
                class: "error-bg",
                src: Te,
                alt: ""
            }, null, -1)) ])),
            _: 1
        }, 8, [ "open" ]));
    }
}, [ [ "__scopeId", "data-v-8c6820f7" ] ]), at = {
    key: 0,
    class: "loading"
}, ot = {
    key: 1,
    class: "content-inner"
}, nt =  te({
    __name: "changeLoginType",
    emits: [ "google", "email" ],
    setup(e, {expose: t, emit: a}) {
        const i = a, c = g(!1), d = g(!1), u = window.location.origin, p = () => {
            d.value = !0;
            const e = `https://accounts.google.com/o/oauth2/v2/auth?redirect_uri=${u}&access_type=online&client_id=249369560324-m8mjmp3pfgb2qqbnobmt82n04tqv4i38.apps.googleusercontent.com&response_type=code&scope=email&prompt=consent`;
            window.location.href = e;
        };
        return t({
            openHandle: () => {
                c.value = !0, d.value = !1;
            }
        }), (e, t) => (o(), n(se, {
            open: c.value,
            "onUpdate:open": t[1] || (t[1] = e => c.value = e)
        }, {
            title: s((() => t[2] || (t[2] = [ m(" Login ") ]))),
            default: s((() => [ d.value ? (o(), r("div", at, " Logging in, please wait... ")) : (o(), 
            r("div", ot, [ l("div", {
                class: "btn google",
                onClick: p
            }, t[3] || (t[3] = [ l("span", {
                class: "btn-icon"
            }, null, -1), m("Sign in with Google") ])), l("div", {
                class: "btn email",
                onClick: t[0] || (t[0] = () => {
                    i("email"), c.value = !1;
                })
            }, t[4] || (t[4] = [ l("span", {
                class: "btn-icon"
            }, null, -1), m("Sign in with Email") ])) ])) ])),
            _: 1
        }, 8, [ "open" ]));
    }
}, [ [ "__scopeId", "data-v-d4cc1eae" ] ]), st = {
    __name: "LoginBlock",
    setup(e, {expose: t}) {
        const a = g(), n = () => {
            a.value.openHandle();
        };
        return t({
            openHandle: n
        }), (e, t) => (o(), r("div", null, [ l("div", {
            style: {
                height: "100%",
                width: "100%"
            },
            onClick: n
        }, [ c(e.$slots, "default") ]), A(nt, {
            ref_key: "changeLoginType",
            ref: a,
            onEmail: t[0] || (t[0] = t => e.$refs.loginBlock.openHandle())
        }, null, 512), A(Ue, {
            ref: "loginBlock",
            onError: t[1] || (t[1] = t => e.$refs.loginError.openHandle()),
            onCreate: t[2] || (t[2] = t => e.$refs.createAccount.openHandle()),
            onForget: t[3] || (t[3] = t => e.$refs.SendEmail.openHandle())
        }, null, 512), A(le, {
            ref: "loginError"
        }, null, 512), A(Ee, {
            ref: "createAccount",
            onSuccess: t[4] || (t[4] = t => {
                e.$refs.createTakeCode.openHandle(t), e.$refs.loginBlock.closeHandle();
            })
        }, null, 512), A(Le, {
            ref: "createSuccess",
            onLogin: t[5] || (t[5] = t => e.$refs.loginBlock.openHandle(t))
        }, null, 512), A(xe, {
            ref: "SendEmail",
            onSuccess: t[6] || (t[6] = t => {
                e.$refs.loginBlock.closeHandle(), e.$refs.codeVerification.openHandle(t);
            }),
            onError: t[7] || (t[7] = () => {
                e.$refs.loginBlock.closeHandle(), e.$refs.forgetError.openHandle();
            })
        }, null, 512), A(Qe, {
            ref: "codeVerification",
            onSuccess: t[8] || (t[8] = t => e.$refs.forgetSuccess.openHandle()),
            onError: t[9] || (t[9] = e => d(G).open({
                title: "error",
                content: "Verification failed! Please try again. ",
                type: "error"
            }))
        }, null, 512), A(Ke, {
            ref: "forgetError",
            onCreate: t[10] || (t[10] = () => {
                e.$refs.createAccount.openHandle(), e.$refs.SendEmail.closeHandle();
            })
        }, null, 512), A(tt, {
            ref: "forgetSuccess",
            onClose: t[11] || (t[11] = t => e.$refs.loginBlock.openHandle())
        }, null, 512), A(Ze, {
            ref: "createTakeCode",
            onSuccess: t[12] || (t[12] = t => {
                e.$refs.createSuccess.openHandle(t), e.$refs.createAccount.closeHandle();
            }),
            onError: t[13] || (t[13] = t => e.$refs.verificationFailed.openHandle())
        }, null, 512), A(et, {
            ref: "verificationFailed"
        }, null, 512) ]));
    }
}, rt =  te( Object.assign({
    name: "message"
}, {
    __name: "Message",
    setup(e) {
        const t = ee();
        return (e, a) => (o(), n(p, {
            name: "message"
        }, {
            default: s((() => [ y(l("div", {
                class: i([ "message", d(t).media ])
            }, v(d(t).messageContent), 3), [ [ P, d(t).messageOpen ] ]) ])),
            _: 1
        }));
    }
}), [ [ "__scopeId", "data-v-4a5d42a8" ] ]), lt = {
    class: "btn-group"
}, it =  te({
    __name: "App",
    setup(e) {
        const a = ee(), n = (e, t, o) => {
            var n = e.documentElement, s = n.clientWidth;
            s && (n.style.fontSize = s / o + "px", n.className = a.media + "-html");
        }, c = () => {
            document.documentElement.clientWidth >= 775 ? a.setMedia("pc") : a.setMedia("mobile"), 
            u();
        }, u = () => {
            let e = window.innerHeight, t = window.innerWidth;
            document.documentElement.style.setProperty("--vh", `${e}px`), document.documentElement.style.setProperty("--vw", `${t}px`);
        };
        _((() => {
            c(), u(), n(document, window, a.mediaSize), window.addEventListener("resize", (() => {
                c(), n(document, window, a.mediaSize);
            }));
        })), t((() => a.musicToggle), (() => {
            document.querySelector("audio") && (a.musicToggle ? document.querySelector("audio").play() : document.querySelector("audio").pause());
        }));
        const p = () => {
            window.open("https://quiz-kbwbmaya.narralayer.ai", "_blank"), a.quizOpen = !1;
        };
        return (e, t) => {
            const n = k("router-view");
            return o(), r("div", {
                class: i([ "page", {
                    [d(a).media]: !0
                } ])
            }, [ t[4] || (t[4] = l("audio", {
                loop: "",
                controls: ""
            }, [ l("source", {
                src: "https://oss.narralayer.ai/medias/BGM.wav",
                type: "audio/mpeg"
            }) ], -1)), A(n), A(se, {
                open: d(a).modalOpen,
                "onUpdate:open": t[0] || (t[0] = e => d(a).modalOpen = e),
                title: d(a).modalTitle,
                content: d(a).modalContent,
                type: d(a).modalType
            }, null, 8, [ "open", "title", "content", "type" ]), A(rt), A(se, {
                open: d(a).quizOpen,
                "onUpdate:open": t[2] || (t[2] = e => d(a).quizOpen = e),
                title: "confirm"
            }, {
                default: s((() => [ t[3] || (t[3] = l("div", {
                    class: "text"
                }, " Dear Trainer, Incomplete access detected! Please note that you won’t be able to have the full Narra experience if you’re not logged in. ", -1)), l("div", lt, [ l("button", {
                    class: "btn-item",
                    onClick: t[1] || (t[1] = () => {
                        e.$refs.loginBlock.openHandle(), d(a).quizOpen = !1;
                    })
                }, "Login"), l("button", {
                    class: "btn-item",
                    onClick: p
                }, "Enter QUIZ") ]) ])),
                _: 1
            }, 8, [ "open" ]), A(st, {
                ref: "loginBlock"
            }, null, 512) ], 2);
        };
    }
}, [ [ "__scopeId", "data-v-0488abdc" ] ]), ct = {}, dt = function(e, t, a) {
    let o = Promise.resolve();
    if (t && t.length > 0) {
        document.getElementsByTagName("link");
        const e = document.querySelector("meta[property=csp-nonce]"), a = (null == e ? void 0 : e.nonce) || (null == e ? void 0 : e.getAttribute("nonce"));
        o = Promise.allSettled(t.map((e => {
            if ((e = function(e) {
                return "/narra-homepage/" + e;
            }(e)) in ct) return;
            ct[e] = !0;
            const t = e.endsWith(".css"), o = t ? '[rel="stylesheet"]' : "";
            if (document.querySelector(`link[href="${e}"]${o}`)) return;
            const n = document.createElement("link");
            return n.rel = t ? "stylesheet" : "modulepreload", t || (n.as = "script"), n.crossOrigin = "", 
            n.href = e, a && n.setAttribute("nonce", a), document.head.appendChild(n), t ? new Promise(((t, a) => {
                n.addEventListener("load", t), n.addEventListener("error", (() => a(new Error(`Unable to preload CSS for ${e}`))));
            })) : void 0;
        })));
    }
    function n(e) {
        const t = new Event("vite:preloadError", {
            cancelable: !0
        });
        if (t.payload = e, window.dispatchEvent(t), !t.defaultPrevented) throw e;
    }
    return o.then((t => {
        for (const e of t || []) "rejected" === e.status && n(e.reason);
        return e().catch(n);
    }));
}, ut = L({
    history: H("/narra-homepage/"),
    scrollBehavior: (e, t) => e.fullPath.includes("/about#Founders") ? {
        el: "#Founders",
        top: 0
    } : {
        top: 0
    },
    routes: [ {
        path: "/",
        name: "index",
        component: () => dt((() => import("./index-BOqlvgaB.js")), __vite__mapDeps([0,1,2,3,4,5,6,7,8,9,10,11,12,13,14,15,16,17,18,19,20,21,22,23,24,25,26,27,28,29,30,31,32,33,34,35,36,37,38,39,40,41,42,43,44]))
    }, 
    // {
    //     path: "/home",
    //     name: "home",
    //     component: ()=>import('@/views/home/index.vue'),
    //     meta:{
    //         header:true,
    //         footer:true,
    //     }
    // },
    {
        path: "/mediaKit",
        name: "mediaKit",
        component: () => dt((() => import("./index-B2hzJabX.js")), __vite__mapDeps([45,2,41,3,4,42,7,8,9,10,11,12,13,14,15,16,17,18,19,20,21,22,23,24,25,26,27,28,29,30,31,32,33,34,1,46,44]))
    }, {
        path: "/vision",
        name: "vision",
        component: () => dt((() => import("./index-Cj0GfuLJ.js")), __vite__mapDeps([47,5,6,2,1,3,4,7,8,9,10,11,12,13,14,15,16,17,18,19,20,21,22,23,24,25,26,27,28,29,30,31,32,33,34,35,36,37,38,39,41,42,48,44]))
    }, {
        path: "/chat",
        name: "chat",
        component: () => dt((() => import("./index-BIJtzUic.js")), __vite__mapDeps([49,5,6,2,1,3,4,7,8,9,10,11,12,13,14,15,16,17,18,19,20,21,22,23,24,25,26,27,28,29,30,31,32,33,34,35,36,37,38,40,50,51,52,53,41,42,54,44]))
    }, {
        path: "/chatting/:id",
        name: "chatting",
        component: () => dt((() => import("./index-yEsN7GjR.js")), __vite__mapDeps([55,2,50,3,4,51,6,1,7,8,9,10,11,12,13,14,15,16,17,18,19,20,21,22,23,24,25,26,27,28,29,30,31,32,33,34,35,36,37,41,42,56,44])),
        props: !0
    } ]
});

const pt = (e, t) => {
    const a = e.getBoundingClientRect(), o = window.innerHeight || document.documentElement.clientHeight;
    a.bottom < 0 || a.top > o - (window.innerWidth > 775 ? 300 : 10) || t({
        status: 200,
        message: "进入页面"
    });
}, mt = {
    mounted: (e, t) => {
        const {callback: a} = t.value;
        pt(e, a), window.addEventListener("scroll", (() => pt(e, a)));
    },
    unmounted: () => {
        window.removeEventListener("scroll", (() => pt));
    }
}, vt = {
    mounted(e, t) {
        let a, o, n, s;
        e.addEventListener("touchstart", (function(e) {
            a = e.touches[0].clientX, o = e.touches[0].clientY;
        })), e.addEventListener("touchend", (function(e) {
            n = e.changedTouches[0].clientX, s = e.changedTouches[0].clientY;
            const r = n - a, l = s - o, i = Math.abs(r), c = Math.abs(l);
            i > c ? r > 0 ? t.value("right", i) : t.value("left", i) : l > 0 ? t.value("down", c) : t.value("up", c);
        }));
    }
};

ut.beforeEach((async (e, t, a) => {
    const o = Z();
    S.get("token", o.token) && o.getUserInfo().catch((() => {
        o.logoutHandle();
    })), a();
}));

const gt = E(it);

gt.use(C()), (e => {
    e.directive("inView", mt), e.directive("swipe", vt);
})(gt), gt.use(ut), gt.mount("#app");

export { Qe as C, se as M, xe as S, te as _, ee as a, st as b, X as c, W as d, F as e, he as f, G as g, me as h, V as i, ge as j, N as k, Q as m, D as s, Z as u };
